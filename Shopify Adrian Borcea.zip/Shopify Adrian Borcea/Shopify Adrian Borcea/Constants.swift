//
//  Constants.swift
//  Shopify Adrian Borcea
//
//  Created by Adrian Borcea on 3/22/19.
//  Copyright © 2019 Adrian Borcea. All rights reserved.
//

import Foundation

let customCollectionsUrlString = "https://shopicruit.myshopify.com/admin/custom_collections.json?page=1&access_token=c32313df0d0ef512ca64d5b336a0d7c6"


