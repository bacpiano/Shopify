//
//  ViewController.swift
//  Shopify Adrian Borcea
//
//  Created by Adrian Borcea on 3/22/19.
//  Copyright © 2019 Adrian Borcea. All rights reserved.
//

import UIKit

class CustomCollectionsVC:  UIViewController,
                            UICollectionViewDelegate,
                            UICollectionViewDataSource,
                            UICollectionViewDelegateFlowLayout {
    
    @IBOutlet weak var customCollectionView: UICollectionView!
    
    var customCollectionsArray: [CustomCollectionItem] = []
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.setNavigationBarHidden(true, animated: animated)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        navigationController?.setNavigationBarHidden(false, animated: animated)
    }
    
    
    //VIEW DID LOAD--------------------------------------------------------------------------------------------------------------
    override func viewDidLoad() {
        super.viewDidLoad()
        
        customCollectionView.delegate = nil
        customCollectionView.dataSource = nil
        
        //MAKING SURE URL of 1st API call can be created
        guard let url = URL(string: customCollectionsUrlString) else { print(Errors.urlCreationFailed); return }
        
        //starting URLSession dataTask
        URLSession.shared.dataTask(with: url) { (data, response, err) in
            //MAKING SURE we have some data to grab from the url
            guard let data = data else { print(Errors.grabbingJsonDataFailed); return }
            //CHECKING the response
            if let response = response as? HTTPURLResponse {
                //MAKING SURE statusCode from response is 200, meaning we're good to go.
                guard response.statusCode == 200
                    else { print(Errors.statusCode200Failed, response.statusCode); return }
            }
            else { print(Errors.responseCastingFailed); return }
            
            do {//MAKING SURE the json data can be serialized
                guard let json = try JSONSerialization.jsonObject(with: data, options: .mutableContainers) as? [String : Any]
                    else { print(Errors.jsonSerializationFailed); return }
                
                //MAKING SURE the array of [String:Any] from the custom_collections root node can be grabbed
                guard let jsonCustomCollectionsNSArray = json["custom_collections"] as? NSArray
                    else { print(Errors.grabbingNSArrayFailed); return }
                
                //MAKING SURE we have at least 1 collection entry in the NSArray.
                guard jsonCustomCollectionsNSArray.count > 0
                    else { print(Errors.jsonNSArrayIsEmpty); return }
                
                //populating the customCollectionsArray
                for (index, jsonCollectionsEntry) in jsonCustomCollectionsNSArray.enumerated() {
                    //CHECKING if entry can be cast to [String:Any]
                    if let customCollectionsEntry = jsonCollectionsEntry as? [String : Any] {
                        //add customCollectionEntry to customCollectionsArray
                        self.customCollectionsArray.append(CustomCollectionItem(json: (customCollectionsEntry)))
                        //TEST PRINTING image src
//                        print("Image \(index + 1) url is:", self.customCollectionsArray[index].image?.src ?? "nil")
                    }
                }
                
                DispatchQueue.main.async {
                    self.customCollectionView.delegate = self
                    self.customCollectionView.dataSource = self
                    self.customCollectionView.reloadData()
                }
            }
            //catching error if there was one
            catch let jsonErr { print(Errors.jsonCaught, jsonErr) }
            
            }.resume()
        
        
    }//VIEW DID LOAD closing bracket---------------------------------------------------------------------------------------------
    
    
    
    
    
    
    
    
    
    //CollectionView Protocols Conformance
    //NUMBER OF ITEMS IN SECTION
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
//        print("CustomCollection Count is", customCollectionsArray.count)
        return customCollectionsArray.count
    }
    
    //CELL FOR ITEM AT INDEX PATH
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "customCollectionCell", for: indexPath) as! CustomCollectionCell
        
        //IMAGE---------------------------------------------------------------
        //grabbing the url as string
        let imageUrlString = customCollectionsArray[indexPath.item].image?.src
        //converting url string to URL type
        let imageURL = URL(string: imageUrlString!)
        //downloading image in the background
        DispatchQueue.global().async {
            let imageData = try? Data(contentsOf: imageURL!)
            //make sure your image in this url does exist, otherwise unwrap in a if let check / try-catch
            //jump on main queue to set the downloaded image
            DispatchQueue.main.async {
                //setting the image
                cell.imageView.image = UIImage(data: imageData!)
            }
        }
        
        //TITLE---------------------------------------------------------------
        cell.title.text = customCollectionsArray[indexPath.item].title
        
        //BODY_HTML
        #warning("compose a generic message by concatinating title plus a string saying the description of the collection is coming up soon.")
        cell.body_html.text = customCollectionsArray[indexPath.item].body_html
        
        #warning("Style those if necessary.")
        //PUBLISHED_AT
        cell.published_at.text = customCollectionsArray[indexPath.item].published_at
        
        //UPDATED_AT
        cell.updated_at.text = customCollectionsArray[indexPath.item].updated_at
        
        //ID
        if let id = customCollectionsArray[indexPath.item].id {
            cell.id.text = String(id)
        }
        
        
        return cell
    }
    
    //DID SELECT ITEM AT INDEX PATH
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        //do some stuff here
        
        guard let collectionId = customCollectionsArray[indexPath.item].id else {
            print("Could not find a valid collection Id")
            return
        }
        let collectionIdString = String(collectionId)
//        print("Collection ID is", collectionId)
        
        //create url here for the second api call.
        #warning("extract those into constants")
        let collectsUrlPrefix = "https://shopicruit.myshopify.com/admin/collects.json?collection_id="
        let collectsUrlSuffix = "&page=1&access_token=c32313df0d0ef512ca64d5b336a0d7c6"
        collectsQueryURL = collectsUrlPrefix + collectionIdString + collectsUrlSuffix
//        print("CollectsQueryURL is", collectsQueryURL)
        
        //segue to next VC listing products of the tapped collection.
        self.performSegue(withIdentifier: "segueToProductsCollectsVC", sender: self)
        
        
        //pick-up URLSession WITH COLLECTSQUERYURL in ProductsCollectsVC viewDidLoad
        
        
    }
    
    //SIZE FOR ITEM AT INDEX PATH
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        
        return CGSize(width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height / 4)
    }
}

