//
//  Product.swift
//  Shopify Adrian Borcea
//
//  Created by Adrian Borcea on 3/24/19.
//  Copyright © 2019 Adrian Borcea. All rights reserved.
//

import Foundation

struct Product {
    let id: Int?
    let title: String?
    let body_html: String?
    let vendor: String?
    let product_type: String?
    let created_at: String?
    let handle: String?
    let updated_at: String?
    let published_at: String?
    let template_suffix: String?
    let tags: String?//separated by commas
    let published_scope: String?
    let admin_graphql_api_id: String?
    
    //struct for creating ProductVariant instances below.
    //Must populate this array in Product initializer
    let variants: [ProductVariant]?
    
    //struct for creating ProductOption instances below.
    //Must populate this array in Product initializer
    let options: [ProductOption]?
    
    //struct for creating MainProductImage below.
    let image: MainProductImage?
    
    //Nested Structs
    struct ProductVariant {
        let id: Int?
        let product_id: Int?
        let title: String?
        let price: String?
        let sku: String?
        let position: Int?
        let inventory_policy: String?
        let compare_at_price: String?
        let fulfillment_service: String?
        let inventory_management: String?
        let option1: String?
        let option2: String?
        let option3: String?
        let created_at: String?
        let updated_at: String?
        let taxable: Bool?
        let barcode: String?
        let grams: Int?
        let image_id: String?
        let weight: Double?
        let weight_unit: String?
        let inventory_item_id: Int?
        let inventory_quantity: Int?
        let old_inventory_quantity: Int?
        let requires_shipping: Bool?
        let admin_graphql_api_id: String?
        
        init(json: [String : Any]) {
            id = json["id"] as? Int ?? nil
            product_id = json["product_id"] as? Int ?? nil
            title = json["title"] as? String ?? nil
            price = json["price"] as? String ?? nil
            sku = json["sku"] as? String ?? nil
            position = json["position"] as? Int ?? nil
            inventory_policy = json["inventory_policy"] as? String ?? nil
            compare_at_price = json["compare_at_price"] as? String ?? nil
            fulfillment_service = json["fulfillment_service"] as? String ?? nil
            inventory_management = json["inventory_management"] as? String ?? nil
            option1 = json["option1"] as? String ?? nil
            option2 = json["option2"] as? String ?? nil
            option3 = json["option3"] as? String ?? nil
            created_at = json["created_at"] as? String ?? nil
            updated_at = json["updated_at"] as? String ?? nil
            taxable = json["taxable"] as? Bool ?? nil
            barcode = json["barcode"] as? String ?? nil
            grams = json["grams"] as? Int ?? nil
            image_id = json["image_id"] as? String ?? nil
            weight = json["weight"] as? Double ?? nil
            weight_unit = json["weight_unit"] as? String ?? nil
            inventory_item_id = json["inventory_item_id"] as? Int ?? nil
            inventory_quantity = json["inventory_quantity"] as? Int ?? nil
            old_inventory_quantity = json["old_inventory_quantity"] as? Int ?? nil
            requires_shipping = json["requires_shipping"] as? Bool ?? nil
            admin_graphql_api_id = json["admin_graphql_api_id"] as? String ?? nil
            
        }
    }
    
    struct ProductOption {
        let id: Int?
        let product_id: Int?
        let name: String?
        let position: Int?
        let values: [String]?
        
        init(json: [String : Any]) {
            id = json["id"] as? Int ?? nil
            product_id = json["product_id"] as? Int ?? nil
            name = json["name"] as? String ?? nil
            position = json["position"] as? Int ?? nil
            values = json["values"] as? [String] ?? nil
        }
    }
    
    struct MainProductImage {
        let id: Int?
        let product_id: Int?
        let position: Int?
        let created_at: String?
        let updated_at: String?
        let alt: String?
        let width: Int?
        let height: Int?
        let src: String?
        let variant_ids: [Int]?
        let admin_graphql_api_id: String?
        
        init(json: [String : Any]) {
            id = json["id"] as? Int ?? nil
            product_id = json["product_id"] as? Int ?? nil
            position = json["position"] as? Int ?? nil
            created_at = json["created_at"] as? String ?? nil
            updated_at = json["updated_at"] as? String ?? nil
            alt = json["alt"] as? String ?? nil
            width = json["width"] as? Int ?? nil
            height = json["height"] as? Int ?? nil
            src = json["src"] as? String ?? nil
            variant_ids = json["variant_ids"] as? [Int] ?? nil
            admin_graphql_api_id = json["admin_graphql_api_id"] as? String ?? nil
        }
    }
    
    init(json: [String : Any]) {
        id = json["id"] as? Int ?? nil
        title = json["title"] as? String ?? nil
        body_html = json["body_html"] as? String ?? nil
        vendor = json["vendor"] as? String ?? nil
        product_type = json["product_type"] as? String ?? nil
        created_at = json["created_at"] as? String ?? nil
        handle = json["json"] as? String ?? nil
        updated_at = json["updated_at"] as? String ?? nil
        published_at = json["published_at"] as? String ?? nil
        template_suffix = json["template_suffix"] as? String ?? nil
        tags = json["tags"] as? String ?? nil
        published_scope = json["published_scope"] as? String ?? nil
        admin_graphql_api_id = json["admin_graphql_api_id"] as? String ?? nil
        
        //VARIANTS
        if let jsonVariantsNSArray = json["variants"] as? [[String:Any]] {
            var productVariants: [ProductVariant] = []
            for jsonVariantsNSArrayEntry in jsonVariantsNSArray {
                productVariants.append(ProductVariant(json: jsonVariantsNSArrayEntry))
            }
            variants = productVariants
        }
        else { variants = nil }
        
        //OPTIONS
        if let jsonOptionsNSArray = json["options"] as? [[String:Any]] {
            var productOptions: [ProductOption] = []
            for jsonOptionsNSArrayEntry in jsonOptionsNSArray {
                productOptions.append(ProductOption(json: jsonOptionsNSArrayEntry))
            }
            options = productOptions
        }
        else { options = nil }
        
        //IMAGE
        if let jsonImage = json["image"] as? [String:Any] {
            image = MainProductImage(json: jsonImage)
        }
        else { image = nil }
        
    }
    
}
