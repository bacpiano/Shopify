//
//  CollectsProduct.swift
//  Shopify Adrian Borcea
//
//  Created by Adrian Borcea on 3/24/19.
//  Copyright © 2019 Adrian Borcea. All rights reserved.
//


//this is the json model for what we retrieve from the 2nd API call
struct CollectsProduct {
    let id: Int?
    let collection_id: Int?
    let product_id: Int? // used for 3rd api call. store in array to create url
    let featured: Bool?
    let created_at: String?
    let updated_at: String?
    let position: Int?
    let sort_value: String?
    
    init(json: [String : Any]) {
        id = json["id"] as? Int ?? nil
        collection_id = json["collection_id"] as? Int? ?? nil
        product_id = json["product_id"] as? Int ?? nil
        featured = json["featured"] as? Bool? ?? nil
        created_at = json["created_at"] as? String ?? nil
        updated_at = json["updated_at"] as? String ?? nil
        position = json["position"] as? Int ?? nil
        sort_value = json["sort_value"] as? String ?? nil
    }
}
