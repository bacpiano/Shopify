//
//  CustomCollectionCell.swift
//  Shopify Adrian Borcea
//
//  Created by Adrian Borcea on 3/23/19.
//  Copyright © 2019 Adrian Borcea. All rights reserved.
//

import UIKit

class CustomCollectionCell: UICollectionViewCell {
    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var title: UILabel!
    @IBOutlet weak var body_html: UILabel!
    @IBOutlet weak var published_at: UILabel!
    @IBOutlet weak var updated_at: UILabel!
    @IBOutlet weak var id: UILabel!
}
