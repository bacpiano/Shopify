//
//  Global Variables.swift
//  Shopify Adrian Borcea
//
//  Created by Adrian Borcea on 3/24/19.
//  Copyright © 2019 Adrian Borcea. All rights reserved.
//

import Foundation

var collectsQueryURL = ""
var productsQueryURL = ""
