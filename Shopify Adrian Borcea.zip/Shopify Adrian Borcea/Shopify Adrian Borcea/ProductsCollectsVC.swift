//
//  CollectsVC.swift
//  Shopify Adrian Borcea
//
//  Created by Adrian Borcea on 3/24/19.
//  Copyright © 2019 Adrian Borcea. All rights reserved.
//

import UIKit

class ProductsCollectsVC:   UIViewController,
                            UICollectionViewDelegate,
                            UICollectionViewDataSource,
                            UICollectionViewDelegateFlowLayout {
    
    @IBOutlet weak var productsCollectionView: UICollectionView!
    
    //represents product data from a given collection (tapped by user)
    var productsCollectsArray: [CollectsProduct] = []
    var productsArray: [Product] = []
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        productsCollectionView.delegate = nil
        productsCollectionView.dataSource = nil
        
        //MAKING SURE
        guard let collectsUrl = URL(string: collectsQueryURL) else {
            print("Could not create url from collectsQueryURL")
            return
        }
        
        URLSession.shared.dataTask(with: collectsUrl) { (data, response, err) in
            //MAKING SURE we have some data to grab from the url
            guard let data = data else { print(Errors.grabbingJsonDataFailed); return }
            //CHECKING the response
            if let response = response as? HTTPURLResponse {
                //MAKING SURE statusCode from response is 200, meaning we're good to go.
                guard response.statusCode == 200
                    else { print(Errors.statusCode200Failed, response.statusCode); return }
            }
            else { print(Errors.responseCastingFailed); return }
            
            do {//MAKING SURE the json data can be serialized
                guard let json = try JSONSerialization.jsonObject(with: data, options: .mutableContainers) as? [String : Any]
                    else { print(Errors.jsonSerializationFailed); return }
                
                //MAKING SURE the array of [String:Any] from the collects root node can be grabbed
                guard let jsonProductsCollectsNSArray = json["collects"] as? NSArray
                    else { print(Errors.grabbingNSArrayFailed); return }
                
                //MAKING SURE we have at least 1 collection entry in the NSArray.
                guard jsonProductsCollectsNSArray.count > 0
                    //add error case for below
                    else { print(Errors.jsonNSArrayIsEmpty); return }
                
                //populating the productsCollectsArray
                for (index, jsonProductsCollectsEntry) in jsonProductsCollectsNSArray.enumerated() {
                    //CHECKING if entry can be cast to [String:Any]
                    if let productsCollectsEntry = jsonProductsCollectsEntry as? [String : Any] {
                        //add productsCollectsEntry to productsCollectsArray
                        self.productsCollectsArray.append(CollectsProduct(json: (productsCollectsEntry)))
                        
//                        print("Id of first collectsProduct is", self.productsCollectsArray[index].product_id ?? nil)
                    }
                }
                //this is used (with urlPrefix and urlSuffix) to construct the URL for the 3rd API call
                var productIdsString: String {
                    var commaSeparatedProductIdsString = ""
                    for (index, productsCollectsEntry) in self.productsCollectsArray.enumerated() {
                        if let productId = productsCollectsEntry.product_id {
                            let productIdString = String(productId)
                            commaSeparatedProductIdsString += productIdString
                            if index < self.productsCollectsArray.count - 1 {
                                commaSeparatedProductIdsString += ","
                            }
                        }
                    }
                    return commaSeparatedProductIdsString
                }
                //creating the url for the 3rd Api call to gather products in a collection
                #warning ("Extract those into constants")
                let urlPrefix = "https://shopicruit.myshopify.com/admin/products.json?ids="
                let urlSuffix = "&page=1&access_token=c32313df0d0ef512ca64d5b336a0d7c6"
                productsQueryURL = urlPrefix + productIdsString + urlSuffix
                print("Products Query URL is", productsQueryURL)
                
                
                //-----------------------------------------------------------------------------------------------
                //Make 3rd API call to grab products data to populate productsCollectionView
                //MAKING SURE
                print("ProductsQueryURL String is", productsQueryURL)
                guard let productsUrl = URL(string: productsQueryURL) else {
                    #warning("HANDLE THIS in the UI")
                    print("Could not create url from productsQueryURL")
                    return
                }
                
                URLSession.shared.dataTask(with: productsUrl) { (data, response, err) in
                    //MAKING SURE we have some data to grab from the url
                    guard let data = data else { print(Errors.grabbingJsonDataFailed); return }
                    
                    //            print("Data in 3rd API call grabbed successfully")
                    
                    //CHECKING the response
                    if let response = response as? HTTPURLResponse {
                        //MAKING SURE statusCode from response is 200, meaning we're good to go.
                        guard response.statusCode == 200
                            else { print(Errors.statusCode200Failed, response.statusCode); return }
                        //                print("Response code from 3rd API call ok")
                    }
                    else { print(Errors.responseCastingFailed); return }
                    
                    do {//MAKING SURE the json data can be serialized
                        guard let json = try JSONSerialization.jsonObject(with: data, options: .mutableContainers) as? [String : Any]
                            else { print(Errors.jsonSerializationFailed); return }
                        //                print("Successfully serialized JSON data from 3rd API call")
                        
                        //MAKING SURE the array of [String:Any] from the products root node can be grabbed
                        guard let jsonProductsNSArray = json["products"] as? NSArray
                            else { print(Errors.grabbingNSArrayFailed); return }
                        
                        //                print("Successfully grabbed jsonProductsNSArray from the 3rd API call")
                        
                        //MAKING SURE we have at least 1 collection entry in the NSArray.
                        guard jsonProductsNSArray.count > 0
                            //add error case for below
                            else { print(Errors.jsonNSArrayIsEmpty); return }
                        
                        //                print("Verified that we have at least 1 item in the jsonProductsNSArray")
                        
                        //populating the productsArray
                        for jsonProductsEntry in jsonProductsNSArray {
                            //CHECKING if entry can be cast to [String:Any]
                            if let productsEntry = jsonProductsEntry as? [String : Any] {
                                //add productsCollectsEntry to productsCollectsArray
                                self.productsArray.append(Product(json: (productsEntry)))
                                
                                //                        print("Id of first Product is", self.productsArray[index].id ?? nil)
                            }
                        }
                        //                print("Products Array is", self.productsArray)
                        
                        //MOVE THIS to the 3rd api call
                        DispatchQueue.main.async {
                            self.productsCollectionView.delegate = self
                            self.productsCollectionView.dataSource = self
                            self.productsCollectionView.reloadData()
                        }
                    }
                        //catching error if there was one
                    catch let jsonErr { print(Errors.jsonCaught, jsonErr) }
                    
                    
                    }.resume()
                
                
            }
                //catching error if there was one
            catch let jsonErr { print(Errors.jsonCaught, jsonErr) }
            
        }.resume()
        
        
        
        
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    //Collection View PROTOCOLS CONFORMANCE
    //NUMBER OF ITEMS IN SECTION
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return Int()
    }
    
    //CELL FOR ITEM AT INDEX PATH
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        return UICollectionViewCell()
    }
    
    //SIZE FOR ITEM AT INDEX PATH
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize()
    }
    
    //DID SELECT ITEM AT INDEX PATH
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        //do some stuff
        
    }
    
    
}
