//
//  Errors.swift
//  Shopify Adrian Borcea
//
//  Created by Adrian Borcea on 3/23/19.
//  Copyright © 2019 Adrian Borcea. All rights reserved.
//

import Foundation

enum Errors: String {
    case urlCreationFailed = "COULD NOT CREATE URL FROM STRING. guard let URL FAILED."
    case grabbingJsonDataFailed = "ERROR GRABBING JSON DATA. guard let data FAILED."
    case statusCode200Failed = "STATUS CODE FROM URL RESPONSE RETURNED. guard response.statusCode == 200 FAILED with statusCode"
    case responseCastingFailed = "FAILED TO CONVERT RESPONSE TO HTTPURLResponse"
    case jsonSerializationFailed = "COULD NOT INITIALIZE JSON OBJECT. guard let json statement to Serialize FAILED."
    case grabbingNSArrayFailed = "COULD NOT GET THE CUSTOMCOLLECTIONSARRAY. guard let customCollectionsArray FAILED."
    case jsonNSArrayIsEmpty = "THERE ARE NO AVAILABLE COLLECTIONS AT THIS TIME. guard customCollectionsArray.count > 0 FAILED."
    case jsonCaught = "Caught json serialization error"
}
