//
//  CustomCollection.swift
//  Shopify Adrian Borcea
//
//  Created by Adrian Borcea on 3/22/19.
//  Copyright © 2019 Adrian Borcea. All rights reserved.
//


struct CustomCollectionItem {
    let id: Int?
    let handle: String?
    let title: String?
    let updated_at: String?
    let body_html: String?
    let published_at: String?
    let sort_order: String?
    let template_suffix: String?
    let published_scope: String?
    let admin_graphql_api_id: String?
    let image: CustomCollectionItemImage?
    
    init(json: [String : Any]) {
        id = json["id"] as? Int ?? nil
        handle = json["handle"] as? String ?? nil
        title = json["title"] as? String ?? nil
        updated_at = json["updated_at"] as? String ?? nil
        body_html = json["body_html"] as? String ?? nil
        published_at = json["published_at"] as? String ?? nil
        sort_order = json["sort_order"] as? String ?? nil
        template_suffix = json["template_suffix"] as? String ?? nil
        published_scope = json["published_scope"] as? String ?? nil
        admin_graphql_api_id = json["admin_graphql_api_id"] as? String ?? nil
        if let dictionaryImage = json["image"] as? [String : Any] { image = CustomCollectionItemImage(json: dictionaryImage) }
        else { image = nil }
        
    }
    
    struct CustomCollectionItemImage {
        let created_at: String?
        let alt: String?
        let width: Int?
        let height: Int?
        let src: String?
        
        init(json: [String : Any]) {
            created_at = json["created_at"] as? String ?? nil
            alt = json["alt"] as? String ?? nil
            width = json["width"] as? Int ?? nil
            height = json["height"] as? Int ?? nil
            src = json["src"] as? String ?? nil
            
        }
    }
    
}









 
 


